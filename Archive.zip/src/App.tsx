import React from "react";
import "./App.css";
import Labs from "./Labs";

function App() {
  return (
    <div>
      <h1>Welcome to Web Dev!!</h1>
      <Labs />
    </div>
  );
}

export default App;
