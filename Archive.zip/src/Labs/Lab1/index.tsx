export default function Lab1() {
    return (
      <div>
        <h2>Lab 1</h2>
        <h3>Exercise 1.1</h3>
        <h3>Exercise 1.2</h3>
        <h3>Exercise 1.3</h3>
      </div>
    );
  }