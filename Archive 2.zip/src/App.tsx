import React from "react";
import "./App.css";
import Labs from "./Labs";
import Kanbas from "./Kanbas";

function App() {
  return (
    <div>
      <h1>Welcome to Web Dev!!</h1>
      <Labs />
      <Kanbas />
    </div>
  );
}

export default App;
