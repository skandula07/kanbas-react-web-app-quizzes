import { useParams } from "react-router";
import { BsGripVertical } from "react-icons/bs";
import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import QuizControls from "./QuizControls";
import QuizControlButtons from "./QuizControlButtons";
import { addQuiz, updateQuiz, deleteQuiz } from "./reducer";

export default function Quizzes() {
  const { cid } = useParams(); // Course ID from URL
  const [QuizName, setQuizName] = useState("");
  const { quizzes } = useSelector((state: any) => state.quizzesReducer); // Redux state
  const dispatch = useDispatch();
 
  
    // Function to handle adding a new quiz
    const addQuizHandler = () => {
      if (quizName.trim()) {
        dispatch(addQuiz({ name: quizName, course: cid }));
        setQuizName(""); // Clear the input after adding
      }
    };
  return (
    <div>
      {/* Quiz Controls */}
      <QuizControls
        quizName={quizName}
        setQuizName={setQuizName}
        addQuiz={addQuizHandler}
      />
     
      <br />
      <br />
      <br />
      <br />

      {/* Quizs List */}
      <ul id="wd-quizzes" className="list-group rounded-0">
        {quizzes
          .filter((quiz: any) => quiz.course === cid)
          .map((quiz: any) => (
            <li
              key={quiz._id}
              className="wd-quizzes list-group-item p-0 mb-5 fs-5 border-gray"
            >
              <div className="wd-title p-3 ps-2 bg-white">
                <BsGripVertical className="me-2 fs-3" />

                {/* Toggle between Viewing and Editing */}
                {!quiz.editing && quiz.title}
                {quiz.editing && (
                  <input
                    className="form-control w-50 d-inline-block"
                    onChange={(e) =>
                      dispatch(
                        updateQuiz({ ...quiz, title: e.target.value })
                      )
                    }
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        dispatch(updateQuiz({ ...quiz, editing: false }));
                      }
                    }}
                    defaultValue={quiz.title}
                  />
                )}

                {/* Quiz Control Buttons */}
                <QuizControlButtons
                  quizId={quiz._id}
                  deleteQuiz={(quizId) => {
                    dispatch(deleteQuiz(quizId));
                  }}
                  editQuiz={(quizId) =>
                    dispatch(updateQuiz({ ...quiz, editing: true }))
                  }
                />
              </div>
            </li>
          ))}
      </ul>
    </div>
  );
}
