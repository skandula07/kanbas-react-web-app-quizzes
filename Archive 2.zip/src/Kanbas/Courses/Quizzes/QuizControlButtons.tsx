import { IoEllipsisVertical } from "react-icons/io5";
import { BsPlus } from "react-icons/bs";
import GreenCheckmark from "./GreenCheckmark";
import { FaTrash } from "react-icons/fa";
import { FaPencil } from "react-icons/fa6";

interface QuizControlButtonsProps {
  quizId: string;
  deleteQuiz: (quizId: string) => void; // Expect quizId
  editQuiz: (quizId: string) => void; // Expect quizId
}

export default function QuizControlButtons({
  quizId,
  deleteQuiz,
  editQuiz,
}: QuizControlButtonsProps) {
  return (
    <div className="float-end">
      {/* Edit Button */}
      <FaPencil onClick={() => editQuiz(quizId)} className="text-primary me-3" />

      {/* Delete Button */}
      <FaTrash
        className="text-danger me-2 mb-1"
        onClick={() => deleteQuiz(quizId)} // Pass quizId
      />

      <GreenCheckmark />
      <IoEllipsisVertical className="fs-4" />
      <BsPlus />
    </div>
  );
}
