const Kanbas = () => {
    return(<div>hello world</div>)
}

export default Kanbas;