import Lab1 from "./Lab1";
import Lab2 from "./Lab2";

export default function Labs() {
  return (
    <div>
      <h1>Labs</h1>
      <Lab1 />
      <Lab2 />
    </div>
  );
}